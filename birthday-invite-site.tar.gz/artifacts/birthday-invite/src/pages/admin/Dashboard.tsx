import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Users, CheckCircle2, HelpCircle, XCircle,
  LogOut, Search, Edit2, Trash2, Loader2,
  Baby, UserRound,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

import {
  useGetAdminStats,
  useListGuests,
  useUpdateGuest,
  useDeleteGuest,
  getListGuestsQueryKey,
  getGetAdminStatsQueryKey,
  type Guest,
} from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";

export default function AdminDashboard() {
  const { isAuthenticated, authHeaders, logout } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) setLocation("/admin/login");
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated || !authHeaders) return null;

  return (
    <div className="min-h-screen bg-muted/20 pb-20">
      <header className="bg-white border-b border-border sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-lg sm:text-2xl font-display text-primary">Painel do Organizador</h1>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-muted-foreground hover:text-destructive transition-colors font-bold px-3 py-2 rounded-lg hover:bg-destructive/10 text-sm"
          >
            <LogOut className="w-4 h-4" /> <span className="hidden sm:inline">Sair</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        <StatsGrid authHeaders={authHeaders} />
        <GuestManager authHeaders={authHeaders} />
      </main>
    </div>
  );
}

function StatsGrid({ authHeaders }: { authHeaders: Record<string, string> }) {
  const { data: stats, isLoading } = useGetAdminStats({ request: authHeaders });

  if (isLoading)
    return (
      <div className="h-24 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  if (!stats) return null;

  const cards = [
    { label: "Respostas", value: stats.total, icon: Users, color: "text-blue-500", bg: "bg-blue-100" },
    { label: "Confirmados", value: stats.confirmed, icon: CheckCircle2, color: "text-green-600", bg: "bg-green-100" },
    { label: "Talvez", value: stats.maybe, icon: HelpCircle, color: "text-yellow-600", bg: "bg-yellow-100" },
    { label: "Não vão", value: stats.declined, icon: XCircle, color: "text-red-500", bg: "bg-red-100" },
    { label: "Total Adultos", value: stats.totalAdults, icon: UserRound, color: "text-violet-500", bg: "bg-violet-100" },
    { label: "Total Crianças", value: stats.totalChildren, icon: Baby, color: "text-pink-500", bg: "bg-pink-100" },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((s, i) => {
        const Icon = s.icon;
        return (
          <div key={i} className="bg-white p-4 rounded-2xl shadow-sm border border-border flex flex-col items-center text-center gap-2">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.bg}`}>
              <Icon className={`w-5 h-5 ${s.color}`} />
            </div>
            <p className="text-2xl font-display text-foreground">{s.value}</p>
            <p className="text-xs font-bold text-muted-foreground leading-tight">{s.label}</p>
          </div>
        );
      })}
    </div>
  );
}

function GuestManager({ authHeaders }: { authHeaders: Record<string, string> }) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [editingGuest, setEditingGuest] = useState<Guest | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const { data, isLoading } = useListGuests(
    { page, limit: 10, search: debouncedSearch, status: statusFilter || undefined },
    { request: authHeaders },
  );

  const queryClient = useQueryClient();

  const deleteMutation = useDeleteGuest({
    request: authHeaders,
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGuestsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
      },
    },
  });

  const handleDelete = (id: number) => {
    if (window.confirm("Excluir esta resposta?")) {
      deleteMutation.mutate({ id });
    }
  };

  const statusMap: Record<string, { label: string; badge: string }> = {
    confirmed: { label: "Confirmado", badge: "bg-green-100 text-green-700" },
    maybe: { label: "Talvez", badge: "bg-yellow-100 text-yellow-700" },
    declined: { label: "Não vai", badge: "bg-red-100 text-red-700" },
  };

  return (
    <div className="bg-white rounded-3xl shadow-md border border-border overflow-hidden">
      <div className="p-4 sm:p-6 border-b border-border bg-slate-50/50">
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center mb-4">
          <h2 className="text-xl font-bold text-foreground">Lista de Convidados</h2>
          {data && (
            <span className="text-xs font-medium text-muted-foreground bg-muted/40 px-3 py-1 rounded-full">
              {data.totalItems} {data.totalItems === 1 ? "resposta" : "respostas"}
            </span>
          )}
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Buscar nome..."
              className="pl-9 h-11 rounded-xl bg-white border-muted text-sm"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="h-11 rounded-xl border border-input bg-white px-3 outline-none focus:ring-2 focus:ring-primary/20 text-sm"
          >
            <option value="">Todos os status</option>
            <option value="confirmed">Confirmados</option>
            <option value="maybe">Talvez</option>
            <option value="declined">Não vão</option>
          </select>
        </div>
      </div>

      {/* Mobile cards view */}
      <div className="block sm:hidden divide-y divide-border">
        {isLoading ? (
          <div className="p-8 text-center">
            <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
          </div>
        ) : data?.items.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Nenhuma resposta encontrada.</div>
        ) : (
          data?.items.map((guest) => (
            <div key={guest.id} className="p-4 flex gap-3 items-start">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-display text-primary">
                {guest.childName.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-bold text-foreground text-sm truncate">{guest.childName}</p>
                    <p className="text-xs text-muted-foreground truncate">com {guest.parentName}</p>
                    {guest.phone && <p className="text-xs text-muted-foreground">{guest.phone}</p>}
                  </div>
                  <span className={`shrink-0 px-2 py-0.5 rounded-full text-xs font-bold ${statusMap[guest.status].badge}`}>
                    {statusMap[guest.status].label}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="inline-flex items-center gap-1 text-xs bg-blue-50 text-blue-600 font-bold px-2 py-0.5 rounded-full">
                    <UserRound className="w-3 h-3" /> {guest.adultsCount}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs bg-pink-50 text-pink-600 font-bold px-2 py-0.5 rounded-full">
                    <Baby className="w-3 h-3" /> {guest.childrenCount}
                  </span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {format(new Date(guest.createdAt), "dd/MM HH:mm")}
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-1 shrink-0">
                <button
                  onClick={() => setEditingGuest(guest)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(guest.id)}
                  disabled={deleteMutation.isPending}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Desktop table view */}
      <div className="hidden sm:block overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-muted/20 text-muted-foreground text-xs uppercase font-bold tracking-wider">
            <tr>
              <th className="p-4 pl-6">Data</th>
              <th className="p-4">Responsável</th>
              <th className="p-4">Criança</th>
              <th className="p-4 text-center">
                <span className="flex items-center gap-1 justify-center"><UserRound className="w-3 h-3" /> Ad.</span>
              </th>
              <th className="p-4 text-center">
                <span className="flex items-center gap-1 justify-center"><Baby className="w-3 h-3" /> Cr.</span>
              </th>
              <th className="p-4">Status</th>
              <th className="p-4 text-right pr-6">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading ? (
              <tr>
                <td colSpan={7} className="p-8 text-center">
                  <Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" />
                </td>
              </tr>
            ) : data?.items.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-muted-foreground text-sm">
                  Nenhuma resposta encontrada.
                </td>
              </tr>
            ) : (
              data?.items.map((guest) => (
                <tr key={guest.id} className="hover:bg-muted/5 transition-colors">
                  <td className="p-4 pl-6 text-xs text-muted-foreground whitespace-nowrap">
                    {format(new Date(guest.createdAt), "dd/MM 'às' HH:mm")}
                  </td>
                  <td className="p-4 text-sm font-medium text-foreground">
                    {guest.parentName}
                    {guest.phone && (
                      <div className="text-xs text-muted-foreground mt-0.5">{guest.phone}</div>
                    )}
                  </td>
                  <td className="p-4 text-sm font-medium">{guest.childName}</td>
                  <td className="p-4 text-center font-bold text-blue-600">{guest.adultsCount}</td>
                  <td className="p-4 text-center font-bold text-pink-500">{guest.childrenCount}</td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${statusMap[guest.status].badge}`}>
                      {statusMap[guest.status].label}
                    </span>
                  </td>
                  <td className="p-4 pr-6 text-right">
                    <div className="flex justify-end gap-1">
                      <button
                        onClick={() => setEditingGuest(guest)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Editar"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(guest.id)}
                        disabled={deleteMutation.isPending}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.totalPages > 1 && (
        <div className="p-4 border-t border-border flex justify-between items-center bg-slate-50/50">
          <span className="text-xs font-medium text-muted-foreground">
            Pág. {page} de {data.totalPages}
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-4 py-2 rounded-lg bg-white border border-border text-xs font-bold disabled:opacity-50 hover:bg-muted/20"
            >
              Anterior
            </button>
            <button
              onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
              disabled={page === data.totalPages}
              className="px-4 py-2 rounded-lg bg-white border border-border text-xs font-bold disabled:opacity-50 hover:bg-muted/20"
            >
              Próxima
            </button>
          </div>
        </div>
      )}

      {editingGuest && (
        <EditGuestModal
          guest={editingGuest}
          onClose={() => setEditingGuest(null)}
          authHeaders={authHeaders}
        />
      )}
    </div>
  );
}

const updateSchema = z.object({
  parentName: z.string().min(2),
  childName: z.string().min(2),
  phone: z.string().optional().nullable(),
  adultsCount: z.coerce.number().min(1),
  childrenCount: z.coerce.number().min(0),
  status: z.enum(["confirmed", "maybe", "declined"]),
  notes: z.string().optional().nullable(),
});

function EditGuestModal({
  guest,
  onClose,
  authHeaders,
}: {
  guest: Guest;
  onClose: () => void;
  authHeaders: Record<string, string>;
}) {
  const queryClient = useQueryClient();
  const form = useForm({
    resolver: zodResolver(updateSchema),
    defaultValues: {
      parentName: guest.parentName,
      childName: guest.childName,
      phone: guest.phone ?? "",
      adultsCount: guest.adultsCount,
      childrenCount: guest.childrenCount,
      status: guest.status as "confirmed" | "maybe" | "declined",
      notes: guest.notes ?? "",
    },
  });

  const updateMutation = useUpdateGuest({
    request: authHeaders,
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListGuestsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        onClose();
      },
    },
  });

  const onSubmit = (data: z.infer<typeof updateSchema>) => {
    updateMutation.mutate({ id: guest.id, data });
  };

  return (
    <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl w-full sm:max-w-lg overflow-hidden">
        <div className="p-5 border-b border-border flex justify-between items-center">
          <h3 className="text-lg font-bold">Editar Resposta</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1">
            <XCircle className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold block mb-1">Responsável</label>
              <Input {...form.register("parentName")} className="rounded-xl bg-muted/20 h-11 text-sm" />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">Criança</label>
              <Input {...form.register("childName")} className="rounded-xl bg-muted/20 h-11 text-sm" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">Telefone</label>
            <Input {...form.register("phone")} className="rounded-xl bg-muted/20 h-11 text-sm" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold flex items-center gap-1 mb-1">
                <UserRound className="w-3 h-3 text-blue-500" /> Adultos
              </label>
              <Input type="number" {...form.register("adultsCount")} min={1} className="rounded-xl bg-muted/20 h-11 text-sm" />
            </div>
            <div>
              <label className="text-xs font-bold flex items-center gap-1 mb-1">
                <Baby className="w-3 h-3 text-pink-500" /> Crianças
              </label>
              <Input type="number" {...form.register("childrenCount")} min={0} className="rounded-xl bg-muted/20 h-11 text-sm" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">Status</label>
            <select
              {...form.register("status")}
              className="w-full h-11 rounded-xl border border-input bg-muted/20 px-3 outline-none text-sm"
            >
              <option value="confirmed">Confirmado</option>
              <option value="maybe">Talvez</option>
              <option value="declined">Não vai</option>
            </select>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 font-bold text-muted-foreground hover:bg-muted/20 rounded-xl text-sm"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={updateMutation.isPending}
              className="flex-1 px-4 py-3 bg-primary text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 text-sm"
            >
              {updateMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                "Salvar"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
