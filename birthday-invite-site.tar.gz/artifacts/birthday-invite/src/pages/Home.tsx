import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import {
  CheckCircle2, HelpCircle, XCircle, Heart, Loader2,
  Baby, UserRound, Plus, Minus, MapPin, Clock, Calendar,
  ChevronDown, Users,
} from "lucide-react";
import { Link } from "wouter";

import {
  useCreateGuest,
  useListGuests,
  useGetPublicStats,
  getListGuestsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/* ── event data ─────────────────────────────────────── */
const EVENT = {
  childName: "Bento",
  age: "5",
  date: "15/04/2026",
  dateFull: "Quarta-feira, 15 de Abril de 2026",
  time: "18h00 às 22h00",
  location: "Rua Luz Interior, 120",
  neighborhood: "Estrela Sul — Serelepe",
  tagline: "Venha se divertir, jogar, dar risada e fazer parte dessa missão especial!",
};

/* ── schema ─────────────────────────────────────────── */
const rsvpSchema = z.object({
  parentName: z.string().min(2, "Insira seu nome completo."),
  childName: z.string().min(2, "Insira o nome da criança.").optional().nullable().or(z.literal("")),
  phone: z.string().optional().nullable(),
  adultsCount: z.coerce.number().min(1, "Mínimo 1 adulto."),
  childrenCount: z.coerce.number().min(0),
  status: z.enum(["confirmed", "maybe", "declined"]),
  notes: z.string().optional().nullable(),
});
type RsvpFormValues = z.infer<typeof rsvpSchema>;

const statusConfig = {
  confirmed: { label: "Vou sim! ⚔️",  color: "bg-secondary text-white border-secondary", icon: CheckCircle2 },
  maybe:     { label: "Talvez 🤔",     color: "bg-accent text-foreground border-accent",  icon: HelpCircle },
  declined:  { label: "Não vou 💔",    color: "bg-destructive text-white border-destructive", icon: XCircle },
};

/* ══════════════════════════════════════════════════════
   PAGE
══════════════════════════════════════════════════════ */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <HeroSection />
      <RsvpSection />
      <GuestListSection />
      <footer className="py-8 text-center text-muted-foreground text-xs font-medium">
        <p className="flex items-center justify-center gap-1.5">
          Feito com <Heart className="w-3.5 h-3.5 text-destructive fill-destructive" /> para o {EVENT.childName}
        </p>
        <Link href="/admin/login" className="mt-1.5 inline-block text-muted-foreground/50 hover:text-primary transition-colors">
          Área do Organizador
        </Link>
      </footer>
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   HERO — invitation image as the centrepiece
══════════════════════════════════════════════════════ */
function HeroSection() {
  return (
    <section className="relative flex flex-col items-center justify-start overflow-hidden bg-gradient-to-b from-[#1a6b2a] via-[#2d8a40] to-[#4caf50] pt-8 pb-0">
      {/* Pixel grid overlay */}
      <div
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `repeating-linear-gradient(0deg,#000 0,#000 1px,transparent 1px,transparent 32px),
                            repeating-linear-gradient(90deg,#000 0,#000 1px,transparent 1px,transparent 32px)`,
        }}
      />

      {/* Sky top bar */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-[#87CEEB]/60 to-transparent pointer-events-none" />

      {/* Dirt ground strip at the very bottom of hero */}
      <div
        className="absolute bottom-0 left-0 right-0 h-8"
        style={{
          backgroundImage: `repeating-linear-gradient(90deg, #8B6914 0px, #8B6914 32px, #7a5c10 32px, #7a5c10 64px)`,
        }}
      />

      {/* Title banner */}
      <motion.div
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 mb-4 text-center"
      >
        <h1
          className="font-display text-4xl sm:text-5xl md:text-6xl leading-none text-white drop-shadow-[3px_3px_0_rgba(0,0,0,0.6)]"
          style={{ WebkitTextStroke: "1px rgba(0,0,0,0.3)" }}
        >
          VOCÊ ESTÁ CONVIDADO!
        </h1>
      </motion.div>

      {/* Invitation card image — main hero asset */}
      <motion.div
        initial={{ scale: 0.88, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, type: "spring", bounce: 0.3 }}
        className="relative z-10 w-full max-w-sm sm:max-w-md px-4"
      >
        <div className="glow-border rounded-2xl overflow-hidden border-4 border-accent shadow-2xl">
          <img
            src={`${import.meta.env.BASE_URL}images/convite.jpeg`}
            alt={`Convite de aniversário de ${EVENT.childName}`}
            className="w-full h-auto object-contain block"
          />
        </div>
      </motion.div>

      {/* ── Animated CTA ── */}
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.55, type: "spring", bounce: 0.4 }}
        className="relative z-10 mt-6 mb-12 px-4 w-full max-w-xs sm:max-w-sm flex flex-col items-center gap-3"
      >
        {/* Pulsing rings behind the button */}
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="absolute inset-0 rounded-2xl border-4 border-accent pointer-events-none"
            initial={{ scale: 1, opacity: 0.6 }}
            animate={{ scale: 1.5 + i * 0.25, opacity: 0 }}
            transition={{
              duration: 1.6,
              delay: i * 0.45,
              repeat: Infinity,
              ease: "easeOut",
            }}
          />
        ))}

        {/* The button itself — bounces up/down continuously */}
        <motion.button
          onClick={() =>
            document.getElementById("rsvp-section")?.scrollIntoView({ behavior: "smooth" })
          }
          animate={{ y: [0, -7, 0] }}
          transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
          whileHover={{ scale: 1.06, y: -10 }}
          whileTap={{ scale: 0.94, y: 0 }}
          className="relative w-full overflow-hidden rounded-2xl font-display text-xl sm:text-2xl text-foreground select-none cursor-pointer"
          style={{
            background: "linear-gradient(180deg,#FFD54F 0%,#FFA000 100%)",
            boxShadow:
              "inset 0 -5px 0 0 rgba(0,0,0,0.35), 0 5px 0 0 rgba(0,0,0,0.28), 0 8px 20px rgba(0,0,0,0.3)",
            textShadow: "1px 2px 0 rgba(0,0,0,0.35)",
          }}
        >
          {/* Shimmer sweep */}
          <motion.span
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "linear-gradient(110deg, transparent 20%, rgba(255,255,255,0.55) 50%, transparent 80%)",
              transform: "skewX(-15deg)",
            }}
            animate={{ x: ["-120%", "140%"] }}
            transition={{ duration: 2.2, repeat: Infinity, repeatDelay: 1.2, ease: "easeInOut" }}
          />

          <span className="relative px-6 py-4 flex items-center justify-center gap-2 whitespace-nowrap">
            ⚔️ CONFIRMAR PRESENÇA
          </span>
        </motion.button>

        {/* Bouncing chevron below the button */}
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 0.9, repeat: Infinity, ease: "easeInOut" }}
          className="text-accent drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"
        >
          <ChevronDown className="w-7 h-7 stroke-[3]" />
        </motion.div>
      </motion.div>
    </section>
  );
}

/* ══════════════════════════════════════════════════════
   RSVP SECTION
══════════════════════════════════════════════════════ */
function CounterField({
  label, icon: Icon, value, onChange, min = 0, accentClass,
}: {
  label: string; icon: React.ElementType; value: number;
  onChange: (v: number) => void; min?: number; accentClass: string;
}) {
  return (
    <div className="flex items-center justify-between bg-background rounded-xl px-4 py-3 border border-border">
      <div className="flex items-center gap-2">
        <Icon className={cn("w-5 h-5", accentClass)} />
        <span className="font-bold text-sm">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => onChange(Math.max(min, value - 1))}
          className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center hover:bg-border transition-colors active:scale-90"
        >
          <Minus className="w-4 h-4" />
        </button>
        <span className="w-6 text-center font-display text-2xl">{value}</span>
        <button
          type="button"
          onClick={() => onChange(value + 1)}
          className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center hover:bg-primary/80 transition-colors active:scale-90"
        >
          <Plus className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
}

function RsvpSection() {
  const queryClient = useQueryClient();
  const [isSuccess, setIsSuccess] = useState(false);

  const form = useForm<RsvpFormValues>({
    resolver: zodResolver(rsvpSchema),
    defaultValues: { parentName: "", childName: "", phone: "", adultsCount: 1, childrenCount: 1, status: "confirmed", notes: "" },
  });

  const adultsCount = form.watch("adultsCount");
  const childrenCount = form.watch("childrenCount");

  const mutation = useCreateGuest({
    mutation: {
      onSuccess: () => {
        setIsSuccess(true);
        queryClient.invalidateQueries({ queryKey: getListGuestsQueryKey() });
        const end = Date.now() + 3000;
        const rand = (a: number, b: number) => Math.random() * (b - a) + a;
        const iv = setInterval(() => {
          if (Date.now() > end) return clearInterval(iv);
          const n = 50 * ((end - Date.now()) / 3000);
          const base = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };
          confetti({ ...base, particleCount: n, colors: ["#4CAF50","#F6C453","#1a6b2a","#ffffff"], origin: { x: rand(0.1, 0.35), y: Math.random() - 0.2 } });
          confetti({ ...base, particleCount: n, colors: ["#4CAF50","#F6C453","#1a6b2a","#ffffff"], origin: { x: rand(0.65, 0.9), y: Math.random() - 0.2 } });
        }, 250);
      },
    },
  });

  const onSubmit = (data: RsvpFormValues) =>
    mutation.mutate({
      data: {
        ...data,
        childName: data.childName?.trim() || null,
      },
    });

  return (
    <section id="rsvp-section" className="py-10 px-4 bg-background">
      <div className="max-w-lg mx-auto">
        {/* Section header with minecraft banner style */}
        <div className="mb-6 text-center">
          <div className="inline-block bg-primary px-6 py-2 rounded-t-xl">
            <h2 className="font-display text-2xl sm:text-3xl text-white drop-shadow-[1px_1px_0_rgba(0,0,0,0.4)]">
              📋 Lista de Presença
            </h2>
          </div>
          <div className="bg-secondary/20 border border-secondary/30 rounded-b-xl rounded-tr-xl px-4 py-3">
            <div className="flex flex-col gap-1.5 text-sm font-medium text-foreground/80">
              <span className="flex items-center gap-2"><Calendar className="w-4 h-4 text-accent shrink-0" />{EVENT.dateFull}</span>
              <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-accent shrink-0" />{EVENT.time}</span>
              <span className="flex items-center gap-2"><MapPin className="w-4 h-4 text-accent shrink-0" />{EVENT.location} — {EVENT.neighborhood}</span>
            </div>
          </div>
        </div>

        {/* Form card */}
        <div className="bg-card border-2 border-border rounded-2xl shadow-lg overflow-hidden">
          {/* Grass top bar */}
          <div className="h-3 bg-gradient-to-r from-secondary via-[#5dc760] to-secondary" />

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              {isSuccess ? (
                <motion.div
                  key="ok"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-10 flex flex-col items-center gap-4"
                >
                  <div className="w-20 h-20 bg-secondary/20 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10 text-secondary" />
                  </div>
                  <h3 className="text-3xl font-display text-primary">Missão Aceita!</h3>
                  <p className="text-muted-foreground text-sm">Sua presença foi registrada. Nos vemos na festa! 🎮</p>
                  <button onClick={() => { setIsSuccess(false); form.reset(); }} className="text-primary font-bold hover:underline text-sm">
                    Registrar outro convidado
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-4"
                >
                  {/* Responsável */}
                  <div className="space-y-1">
                    <Label className="text-sm font-bold flex items-center gap-1.5">
                      <UserRound className="w-4 h-4 text-primary" /> Seu nome (responsável) *
                    </Label>
                    <Input {...form.register("parentName")} className="h-12 rounded-xl bg-background text-base" placeholder="Ex: Maria Silva" autoComplete="name" />
                    {form.formState.errors.parentName && <p className="text-destructive text-xs">{form.formState.errors.parentName.message}</p>}
                  </div>

                  {/* Criança — opcional */}
                  <div className="space-y-1">
                    <Label className="text-sm font-bold flex items-center gap-1.5">
                      <Baby className="w-4 h-4 text-secondary" />
                      Nome da criança
                      <span className="ml-1 text-xs font-normal text-muted-foreground">(opcional)</span>
                    </Label>
                    <Input
                      {...form.register("childName")}
                      className="h-12 rounded-xl bg-background text-base"
                      placeholder="Deixe vazio se vier sem criança"
                    />
                  </div>

                  {/* WhatsApp */}
                  <div className="space-y-1">
                    <Label className="text-sm font-bold">WhatsApp (opcional)</Label>
                    <Input {...form.register("phone")} type="tel" className="h-12 rounded-xl bg-background text-base" placeholder="(99) 99999-9999" autoComplete="tel" />
                  </div>

                  {/* Contadores */}
                  <div className="space-y-2">
                    <Label className="text-sm font-bold">Quantas pessoas virão?</Label>
                    <CounterField label="Adultos" icon={UserRound} value={adultsCount} onChange={(v) => form.setValue("adultsCount", v, { shouldValidate: true })} min={1} accentClass="text-primary" />
                    <CounterField label="Crianças" icon={Baby} value={childrenCount} onChange={(v) => form.setValue("childrenCount", v, { shouldValidate: true })} min={0} accentClass="text-secondary" />
                    <p className="text-xs text-center text-muted-foreground">
                      Total: <strong>{adultsCount + childrenCount}</strong> {adultsCount + childrenCount === 1 ? "pessoa" : "pessoas"}
                    </p>
                  </div>

                  {/* Status */}
                  <div className="space-y-2">
                    <Label className="text-sm font-bold">Você vai comparecer? *</Label>
                    <div className="flex flex-col gap-2">
                      {(Object.entries(statusConfig) as [keyof typeof statusConfig, typeof statusConfig[keyof typeof statusConfig]][]).map(([val, cfg]) => {
                        const selected = form.watch("status") === val;
                        const Icon = cfg.icon;
                        return (
                          <label key={val} className={cn(
                            "flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all",
                            selected ? `${cfg.color} shadow-md` : "border-border bg-background hover:bg-muted/40 text-muted-foreground"
                          )}>
                            <input type="radio" value={val} className="sr-only" {...form.register("status")} />
                            <Icon className={cn("w-5 h-5 shrink-0", selected ? "text-white" : "")} />
                            <span className="font-bold text-sm">{cfg.label}</span>
                          </label>
                        );
                      })}
                    </div>
                    {form.formState.errors.status && <p className="text-destructive text-xs">{form.formState.errors.status.message}</p>}
                  </div>

                  {/* Observações */}
                  <div className="space-y-1">
                    <Label className="text-sm font-bold">Observações (alergias, etc.)</Label>
                    <Textarea {...form.register("notes")} className="min-h-[80px] rounded-xl bg-background text-base resize-none" placeholder="Escreva aqui..." />
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={mutation.isPending}
                    className="btn-mc w-full bg-secondary text-white py-4 rounded-xl font-display text-xl sm:text-2xl mt-2 flex items-center justify-center gap-2"
                  >
                    {mutation.isPending
                      ? <><Loader2 className="w-5 h-5 animate-spin" /> Enviando...</>
                      : "⚔️ CONFIRMAR PRESENÇA"}
                  </button>

                  {mutation.isError && (
                    <p className="text-center text-destructive font-medium bg-destructive/10 p-3 rounded-xl text-sm">
                      {(mutation.error as any)?.error ?? "Erro ao enviar. Tente novamente."}
                    </p>
                  )}
                </motion.form>
              )}
            </AnimatePresence>
          </div>

          {/* Dirt bottom bar */}
          <div
            className="h-5"
            style={{ backgroundImage: "repeating-linear-gradient(90deg,#8B6914 0px,#8B6914 20px,#7a5c10 20px,#7a5c10 40px)" }}
          />
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════════════
   GUEST LIST + PUBLIC STATS
══════════════════════════════════════════════════════ */
function GuestListSection() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useListGuests({ page, limit: 6, status: "confirmed" });
  const { data: stats } = useGetPublicStats();

  if (isLoading) return (
    <div className="py-12 text-center">
      <Loader2 className="w-7 h-7 animate-spin text-primary mx-auto" />
    </div>
  );

  if (!data || data.items.length === 0) return null;

  return (
    <section className="py-10 px-4 bg-gradient-to-b from-[#e8f5e9] to-background">
      <div className="max-w-lg mx-auto space-y-6">

        {/* ── Stats totais ── */}
        {stats && (
          <div className="bg-primary rounded-2xl overflow-hidden shadow-lg border-2 border-primary/60">
            {/* Title */}
            <div className="px-5 pt-4 pb-2 text-center">
              <h2 className="font-display text-2xl sm:text-3xl text-white drop-shadow-[1px_1px_0_rgba(0,0,0,0.4)]">
                🎮 Aventureiros Confirmados
              </h2>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-3 gap-px bg-white/20 mx-3 mb-4 rounded-xl overflow-hidden">
              {/* Total pessoas */}
              <div className="bg-primary/90 px-3 py-4 text-center flex flex-col items-center gap-1">
                <Users className="w-5 h-5 text-accent" />
                <span className="font-display text-3xl text-white leading-none">{stats.totalPeople}</span>
                <span className="text-white/80 text-xs font-bold leading-tight">Total de<br/>Pessoas</span>
              </div>
              {/* Adultos */}
              <div className="bg-primary/90 px-3 py-4 text-center flex flex-col items-center gap-1">
                <UserRound className="w-5 h-5 text-blue-300" />
                <span className="font-display text-3xl text-white leading-none">{stats.totalAdults}</span>
                <span className="text-white/80 text-xs font-bold leading-tight">Adultos</span>
              </div>
              {/* Crianças */}
              <div className="bg-primary/90 px-3 py-4 text-center flex flex-col items-center gap-1">
                <Baby className="w-5 h-5 text-pink-300" />
                <span className="font-display text-3xl text-white leading-none">{stats.totalChildren}</span>
                <span className="text-white/80 text-xs font-bold leading-tight">Crianças</span>
              </div>
            </div>

            <p className="text-center text-white/70 text-xs font-medium pb-3">
              {stats.totalFamilies} {stats.totalFamilies === 1 ? "família confirmada" : "famílias confirmadas"}
            </p>
          </div>
        )}

        {/* ── Guest cards ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {data.items.map((guest, i) => {
            const initial = (guest.childName || guest.parentName).charAt(0).toUpperCase();
            return (
              <motion.div
                key={guest.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.07 }}
                className="bg-card border-2 border-secondary/20 rounded-xl p-4 flex items-center gap-3 shadow-sm hover:border-secondary/50 transition-colors"
              >
                <div
                  className="w-11 h-11 rounded-lg bg-primary flex items-center justify-center shrink-0 border-2 border-primary/60"
                  style={{ boxShadow: "inset 0 2px 0 rgba(255,255,255,0.2), 0 2px 0 rgba(0,0,0,0.3)" }}
                >
                  <span className="font-display text-white text-xl leading-none">{initial}</span>
                </div>

                <div className="flex-1 min-w-0">
                  {guest.childName ? (
                    <>
                      <p className="font-bold text-foreground truncate text-sm">{guest.childName}</p>
                      <p className="text-xs text-muted-foreground truncate">com {guest.parentName}</p>
                    </>
                  ) : (
                    <p className="font-bold text-foreground truncate text-sm">{guest.parentName}</p>
                  )}
                  <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                    <span className="mc-badge bg-blue-50 border-blue-200 text-blue-700">
                      <UserRound className="w-3 h-3" /> {guest.adultsCount}
                    </span>
                    {guest.childrenCount > 0 && (
                      <span className="mc-badge bg-pink-50 border-pink-200 text-pink-600">
                        <Baby className="w-3 h-3" /> {guest.childrenCount}
                      </span>
                    )}
                    <span className="mc-badge bg-green-50 border-green-200 text-green-700">
                      <CheckCircle2 className="w-3 h-3" /> Confirmado
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {data.totalPages > 1 && (
          <div className="flex justify-center items-center gap-3">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="px-4 py-2 rounded-lg bg-card border border-border text-sm font-bold disabled:opacity-40 hover:bg-muted transition-colors">
              ← Anterior
            </button>
            <span className="text-sm font-bold text-muted-foreground">{page} / {data.totalPages}</span>
            <button onClick={() => setPage(p => Math.min(data.totalPages, p + 1))} disabled={page === data.totalPages}
              className="px-4 py-2 rounded-lg bg-card border border-border text-sm font-bold disabled:opacity-40 hover:bg-muted transition-colors">
              Próxima →
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
